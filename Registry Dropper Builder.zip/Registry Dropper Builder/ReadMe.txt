Our builder works well with any kind of rats, stealers, botnets etc.
DONT SUBMIT TO VIRUS-TOTAL!
